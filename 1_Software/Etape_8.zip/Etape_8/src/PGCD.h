
int PGCD(int A, int B);
